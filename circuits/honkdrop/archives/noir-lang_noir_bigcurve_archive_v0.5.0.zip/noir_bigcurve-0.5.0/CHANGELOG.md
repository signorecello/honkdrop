# Changelog

## [0.5.0](https://github.com/noir-lang/noir_bigcurve/compare/v0.3.1...v0.5.0) (2024-11-08)


### ⚠ BREAKING CHANGES

* update to noir_bignum v0.4.0 ([#10](https://github.com/noir-lang/noir_bigcurve/issues/10))

### Features

* Added predefined curves ([#8](https://github.com/noir-lang/noir_bigcurve/issues/8)) ([582dc80](https://github.com/noir-lang/noir_bigcurve/commit/582dc808886d146d40aee334bbc200ee858ad747))
* Update to noir_bignum v0.4.0 ([#10](https://github.com/noir-lang/noir_bigcurve/issues/10)) ([3930699](https://github.com/noir-lang/noir_bigcurve/commit/3930699251c55ebc45881536723a44faa3fd15ed))
