# Changelog

## [0.2.0](https://github.com/noir-lang/noir_sort/compare/v0.1.0...v0.2.0) (2024-10-24)


### ⚠ BREAKING CHANGES

* update to support Noir 0.36.0 ([#2](https://github.com/noir-lang/noir_sort/issues/2))

### Features

* Update to support Noir 0.36.0 ([#2](https://github.com/noir-lang/noir_sort/issues/2)) ([765047c](https://github.com/noir-lang/noir_sort/commit/765047c479d0ae4d057845290cc4f7d1baf183ed))
